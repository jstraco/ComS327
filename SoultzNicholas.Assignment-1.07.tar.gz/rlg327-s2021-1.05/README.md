# ComS327
Jadyn Gust Jagust@iastate.edu
Matt Karmelich matkarm@iastate.edu
Nick Soultz Ndsoultz@iastate.edu

io_read_npc in io.cpp parses through monster_desc.txt to get all the monsters info in, info is either kept as strings or dice is parsed in dice_roll and then rolled and returns the total roll.
and the color is parsed in get_color, which returns a numeric value describing the ncurses color.
dice_roll and get_color are not called when program is ran.
running the program simply outputs the monsters information.

