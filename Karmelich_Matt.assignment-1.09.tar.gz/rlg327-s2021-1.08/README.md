# ComS327
Jadyn Gust Jagust@iastate.edu
Matt Karmelich matkarm@iastate.edu
Nick Soultz Ndsoultz@iastate.edu

Has an error (not sure if this is our fault or source code) that crashes the program when you try to move.  This is less likely to happen when you use "G" to move.
Player is able to pick up items, equip them, uneqip them, drop them, remove them, view them, and view their description.  Players combat stats is modified by
the weapons they have equip.  Game ends when the players health reaches 0 or the BOSS dies.