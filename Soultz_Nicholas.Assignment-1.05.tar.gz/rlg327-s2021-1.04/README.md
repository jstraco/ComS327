# ComS327
Jadyn Gust Jagust@iastate.edu
Matt Karmelich matkarm@iastate.edu
Nick Soultz Ndsoultz@iastate.edu

got the player to move with the keybinds and got the monsters distance from player for the list. We did not print out any of the keybindings to show what is avaliable but have the required ones implemented.
