# ComS327
Jadyn Gust Jagust@iastate.edu
Matt Karmelich matkarm@iastate.edu
Nick Soultz Ndsoultz@iastate.edu

if you press f the entire dungeon will be printed until you make a movement, then it will go back to the fog of war version, to teleport press g to enter the mode then you can move the cursor around with the arrow keys, the cursor being * pressing g again will allow the character to teleport to the cursors location and pressing r will randomly teleport you in the dungeon.
