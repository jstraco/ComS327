# ComS327
Jadyn Gust Jagust@iastate.edu
Matt Karmelich matkarm@iastate.edu
Nick Soultz Ndsoultz@iastate.edu



